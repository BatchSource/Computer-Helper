Greetings!
********************
Please extract this folder.
Open "launcher.bat" and Computer Helper will open!

Do NOT move, delete, or rename any of the files in the folders or else Computer Helper will not run!
You must run launcher.bat in this exact location or else it will not run.
-----------------------
If you want, you can create a shortcut to your desktop of start.bat.
You can find the official Computer Helper icon in /code/favicon.ico

If you have any suggestions for features I can add, please let me know.

Thanks, Alex.